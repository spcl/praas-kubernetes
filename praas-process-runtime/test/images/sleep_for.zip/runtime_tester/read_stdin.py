def read_stdin(args):
    inp = input("Read something from stdin")
    return inp
