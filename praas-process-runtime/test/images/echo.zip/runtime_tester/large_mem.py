def large_mem(args):
    return ["a"] * 1073741825
