import time

from praassdk import msg


def get_msg(args):
    src = int(args[0])
    return msg.get(src)


def put_msg(args):
    sleep_time = int(args.pop(0))
    target = int(args.pop(0))
    message = args.pop(0)
    time.sleep(sleep_time)
    msg.put(target, message)
    return "Done"
