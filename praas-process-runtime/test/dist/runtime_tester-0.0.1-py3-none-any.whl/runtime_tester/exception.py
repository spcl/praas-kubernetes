def throw(args):
    raise Exception(args[0])
