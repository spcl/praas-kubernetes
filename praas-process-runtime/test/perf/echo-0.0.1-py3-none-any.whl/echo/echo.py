def echo(args):
    return args[0]
