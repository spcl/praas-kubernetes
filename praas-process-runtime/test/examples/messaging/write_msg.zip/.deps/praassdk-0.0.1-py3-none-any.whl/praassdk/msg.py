import pickle
import sys
from typing import Any


def put(target: int, msg: Any):
    serialized_obj = pickle.dumps(msg)
    num_bytes = len(serialized_obj)
    num_bytes = num_bytes.to_bytes(4, "big")
    target = target.to_bytes(4, "big")
    flag = B"\x02"
    result = flag + target + num_bytes + serialized_obj
    sys.stdout.buffer.write(result)
    sys.stdout.buffer.flush()


def get(source: int) -> Any:
    flag = B"\x03"
    source = source.to_bytes(4, "big")
    get_instruction = flag + source
    sys.stdout.buffer.write(get_instruction)
    sys.stdout.buffer.flush()

    length = sys.stdin.buffer.read(4)
    length = int.from_bytes(length, "big")
    msg_bytes = sys.stdin.buffer.read(length)
    return pickle.loads(msg_bytes)
