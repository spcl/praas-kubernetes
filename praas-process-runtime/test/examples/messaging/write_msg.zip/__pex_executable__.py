import sys
import pickle
from messages import writer
args = sys.argv[1:]
result = pickle.dumps(writer.write_msg(args))
result = B'' + result
sys.stdout.buffer.write(result)
