import os
import sys


__INSTALLED_FROM__ = '__PEX_EXE__'


def __re_exec__(argv0, *extra_launch_args):
  os.execv(argv0, [argv0] + list(extra_launch_args) + sys.argv[1:])


__execute__ = __name__ == "__main__"

def __maybe_install_pex__(pex, pex_root, pex_hash):
  from pex.layout import maybe_install
  from pex.tracer import TRACER

  installed_location = maybe_install(pex, pex_root, pex_hash)
  if not __execute__ or not installed_location:
    return installed_location

  # N.B.: This is read upon re-exec below to point sys.argv[0] back to the original pex before
  # unconditionally scrubbing the env var and handing off to user code.
  os.environ[__INSTALLED_FROM__] = pex

  TRACER.log('Executing installed PEX for {} at {}'.format(pex, installed_location))
  __re_exec__(sys.executable, installed_location)


def __maybe_run_venv__(pex, pex_root, pex_path):
  from pex.common import is_exe
  from pex.tracer import TRACER
  from pex.variables import venv_dir

  venv_dir = venv_dir(
    pex_file=pex,
    pex_root=pex_root, 
    pex_hash='a481e3704df32f5c13d90de8cc752cc9fa656a78',
    has_interpreter_constraints=False,
    pex_path=pex_path,
  )
  venv_pex = os.path.join(venv_dir, 'pex')
  if not __execute__ or not is_exe(venv_pex):
    # Code in bootstrap_pex will (re)create the venv after selecting the correct interpreter. 
    return venv_dir

  TRACER.log('Executing venv PEX for {} at {}'.format(pex, venv_pex))
  venv_python = os.path.join(venv_dir, 'bin', 'python')
  __re_exec__(venv_python, '-sE', venv_pex)


def __entry_point_from_filename__(filename):
    # Either the entry point is "__main__" and we're in execute mode or "__pex__/__init__.py" and
    # we're in import hook mode.
    entry_point = os.path.dirname(filename)
    if __execute__:
        return entry_point
    return os.path.dirname(entry_point)


__entry_point__ = None
if '__file__' in locals() and __file__ is not None and os.path.exists(__file__):
  __entry_point__ = __entry_point_from_filename__(__file__)
elif '__loader__' in locals():
  from pkgutil import ImpLoader
  if hasattr(__loader__, 'archive'):
    __entry_point__ = __loader__.archive
  elif isinstance(__loader__, ImpLoader):
    __entry_point__ = __entry_point_from_filename__(__loader__.get_filename())

if __entry_point__ is None:
  sys.stderr.write('Could not launch python executable!\n')
  sys.exit(2)

__installed_from__ = os.environ.pop(__INSTALLED_FROM__, None)
sys.argv[0] = os.path.realpath(__installed_from__ or sys.argv[0])

sys.path[0] = os.path.abspath(sys.path[0])
sys.path.insert(0, os.path.abspath(os.path.join(__entry_point__, '.bootstrap')))

__venv_dir__ = None
if not __installed_from__:
    os.environ['PEX'] = os.path.realpath(__entry_point__)
    from pex.variables import ENV, Variables
    __pex_root__ = Variables.PEX_ROOT.value_or(ENV, '~/.pex')
    if not ENV.PEX_TOOLS and Variables.PEX_VENV.value_or(ENV, False):
      __venv_dir__ = __maybe_run_venv__(
        __entry_point__,
        pex_root=__pex_root__,
        pex_path=ENV.PEX_PATH or (),
      )
    __installed_location__ = __maybe_install_pex__(
      __entry_point__, pex_root=__pex_root__, pex_hash='a481e3704df32f5c13d90de8cc752cc9fa656a78'
    )
    if __installed_location__:
      __entry_point__ = __installed_location__
else:
    os.environ['PEX'] = os.path.realpath(__installed_from__)

from pex.pex_bootstrapper import bootstrap_pex
bootstrap_pex(__entry_point__, execute=__execute__, venv_dir=__venv_dir__)
