from praassdk import msg


def read_msg(args):
    return msg.get(1)
