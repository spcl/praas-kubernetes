import pickle
from typing import Any

import sys


def read_msg(args):
    return get(1)


def get(source: int) -> Any:
    flag = B"\x03"
    source = source.to_bytes(4, "big")
    get_instruction = flag + source
    sys.stdout.buffer.write(get_instruction)
    sys.stdout.buffer.flush()

    length = sys.stdin.buffer.read(4)
    length = int.from_bytes(length, "big")
    msg_bytes = sys.stdin.buffer.read(length)
    return pickle.loads(msg_bytes)

