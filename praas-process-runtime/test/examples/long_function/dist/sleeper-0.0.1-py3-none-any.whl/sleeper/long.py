import time


def long_function(args):
    time_to_sleep = int(args[0])
    time.sleep(time_to_sleep)
