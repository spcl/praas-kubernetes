import sys
from . import msg

func_id: int
msg.__out_buffer = sys.stdout.buffer
msg.__in_buffer = sys.stdin.buffer
