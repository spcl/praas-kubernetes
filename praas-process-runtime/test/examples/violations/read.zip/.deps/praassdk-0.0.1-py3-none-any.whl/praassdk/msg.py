import pickle
from typing import Any, BinaryIO

__out_buffer: BinaryIO
__in_buffer: BinaryIO


def put(target: int, msg: Any):
    serialized_obj = pickle.dumps(msg)
    num_bytes = len(serialized_obj)
    num_bytes = num_bytes.to_bytes(4, "big")
    target = target.to_bytes(4, "big")
    flag = B"\x02"
    result = flag + target + num_bytes + serialized_obj
    __out_buffer.write(result)
    __out_buffer.flush()


def get(source: int) -> Any:
    flag = B"\x03"
    source = source.to_bytes(4, "big")
    get_instruction = flag + source
    __out_buffer.write(get_instruction)
    __out_buffer.flush()

    length = __in_buffer.read(4)
    length = int.from_bytes(length, "big")
    msg_bytes = __in_buffer.read(length)
    return pickle.loads(msg_bytes)
