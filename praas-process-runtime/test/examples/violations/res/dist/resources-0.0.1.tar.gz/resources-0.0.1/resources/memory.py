def large_mem(args):
    return ["a"] * int(args[0])
