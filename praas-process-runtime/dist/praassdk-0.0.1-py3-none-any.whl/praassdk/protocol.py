import abc
import pickle
from typing import Any, Protocol


class ProcessChannel(Protocol):
    @abc.abstractmethod
    def write(self, bytes_like: bytes):
        pass

    @abc.abstractmethod
    def read(self, n: int) -> bytes:
        pass

    @abc.abstractmethod
    def flush(self):
        pass


def __write_obj(obj: Any, buffer: ProcessChannel, raw=False):
    if not raw:
        obj = pickle.dumps(obj)
    num_bytes = len(obj)

    __write_number(num_bytes, buffer)
    buffer.write(obj)


def __write_flag(flag: int, buffer: ProcessChannel):
    as_bytes = bytes([flag])
    buffer.write(as_bytes)


def __write_number(num: int, buffer: ProcessChannel):
    num = num.to_bytes(4, "big")
    buffer.write(num)


def __read_number(buffer: ProcessChannel):
    num = buffer.read(4)
    return int.from_bytes(num, "big")


def __read_obj(buffer: ProcessChannel, raw=False):
    length = __read_number(buffer)
    obj = buffer.read(length)
    if not raw:
        obj = pickle.loads(obj)
    return obj


def __read_flag(buffer: ProcessChannel):
    flag = buffer.read(1)
    if len(flag) != 1:
        return -1

    return flag[0]
