import pickle
from typing import Any, IO


def __write_obj(obj: Any, buffer: IO):
    serialized_obj = pickle.dumps(obj)
    num_bytes = len(serialized_obj)

    __write_number(num_bytes, buffer)
    buffer.write(serialized_obj)


def __write_flag(flag: int, buffer: IO):
    as_bytes = bytes([flag])
    buffer.write(as_bytes)


def __write_number(num: int, buffer: IO):
    num = num.to_bytes(4, "big")
    buffer.write(num)


def __read_number(buffer: IO):
    num = buffer.read(4)
    return int.from_bytes(num, "big")


def __read_obj(buffer: IO):
    length = __read_number(buffer)
    obj = buffer.read(length)
    return pickle.loads(obj)


def __read_flag(buffer: IO):
    flag = buffer.read(1)
    if len(flag) != 1:
        return -1

    return flag[0]
