from typing import List


class MsgType:
    RETVAL: int = 1
    PUT: int = 2
    GET: int = 3
    INVOKE: int = 4


class InvokeRequest:
    id: int
    func: str
    process: str
    args: List[str]

    cpu: int
    mem: str
