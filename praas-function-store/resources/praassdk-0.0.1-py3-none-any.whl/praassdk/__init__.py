import sys
from . import msg, types

func_id: int
msg.__out_buffer = sys.stdout.buffer
msg.__in_buffer = sys.stdin.buffer
